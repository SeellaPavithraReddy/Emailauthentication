using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmailApi.Models.Entities
{
    public class EmailRequest
    {
        public string ToEmail { get; set; }
    }
}