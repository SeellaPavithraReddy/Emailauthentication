using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmailClient.Models.Entities
{
    public class View_models
    {
        public User1 user1{get;set;}
        public VerifyOtpRequest verifyOtpRequest{get;set;}
    }
}