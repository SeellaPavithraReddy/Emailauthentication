using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmailClient
{
    public class restUrl
    {
                public const string URL="http://localhost:5281/api/";

    }
}